/* Copyright (C) 2010 Broadcom Corporation.
 * Portions Copyright (C) VMware, Inc. 2007-2010. All Rights Reserved.
 */

#if !defined(TG3_VMWARE_BMAPILNX_DISABLE)

#define SIOTG3CIM				0x89F0

#define TG3_VMWARE_CIM_CMD_ENABLE_NIC		0x0001
#define TG3_VMWARE_CIM_CMD_DISABLE_NIC		0x0002
#define TG3_VMWARE_CIM_CMD_REG_READ		0x0003
#define TG3_VMWARE_CIM_CMD_REG_WRITE		0x0004
#define TG3_VMWARE_CIM_CMD_GET_NIC_PARAM	0x0005
#define TG3_VMWARE_CIM_CMD_GET_NIC_STATUS	0x0006

struct tg3_ioctl_reg_read_req
{
	u32 reg_offset;
	u32 reg_value;
} __attribute__((packed));

struct tg3_ioctl_reg_write_req
{
	u32 reg_offset;
	u32 reg_value;
} __attribute__((packed));

struct tg3_ioctl_get_nic_param_req
{
	u32 version;
	u32 mtu;
	u8  current_mac_addr[8];
} __attribute__((packed));

struct tg3_ioctl_get_nic_status_req
{
	u32 nic_status; // 1: Up, 0: Down
} __attribute__((packed));

struct tg3_ioctl_req
{
	u32 cmd;
	union {
		// no struct for reset_nic command
		struct tg3_ioctl_reg_read_req reg_read;
		struct tg3_ioctl_reg_write_req reg_write;
		struct tg3_ioctl_get_nic_param_req get_nic_param;
		struct tg3_ioctl_get_nic_status_req get_nic_status;
	} cmd_req;
} __attribute__((packed));

static int
tg3_vmware_ioctl_cim(struct net_device *dev, struct ifreq *ifr);

#endif  /* !TG3_VMWARE_BMAPILNX_DISABLED */

static void tg3_vmware_timer(struct tg3 *tp);
